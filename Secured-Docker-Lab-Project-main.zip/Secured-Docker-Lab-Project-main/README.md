# Secured-Docker-Lab-Project
Secured Docker Based Lab: Enforcing end-to-end security
<br>

**Background:** Developing cloud-based infrastructure for developing docker based secured lab environment for different application development is the need of the hour. This project would require nurturing the technical know-how of cloud-based securities and docker components along with security enforcements and testing at different levels.
<br>

**Brief:** Secured docker Lab project would involve technology scopes as: 1) AWS Cloud instances II) Docker and its components III) Cybersecurity tools like Nmap, Metasploit framework, Hydra, John the Ripper, etc.
